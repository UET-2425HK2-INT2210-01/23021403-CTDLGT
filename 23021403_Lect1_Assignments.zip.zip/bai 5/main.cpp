/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
void swap(int &a, int &b){
    int tmp=a;
    a=b;
    b=tmp;
};

void sorted(int &a, int &b){
    if(a>b)
        swap(a,b);
};

int main(){
    int n=5;
    int a[1000];
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    for(int i=0; i<n-1; i++){
        for(int j=0; j<n-1-i; j++){
            sorted(a[j],a[j+1]);
        }
    }
    int sum;
    sum=a[0]+a[n-1];
    cout<<sum<<endl;
    return 0;
}